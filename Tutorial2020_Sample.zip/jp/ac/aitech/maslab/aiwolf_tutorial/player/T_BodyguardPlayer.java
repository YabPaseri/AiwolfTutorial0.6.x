package jp.ac.aitech.maslab.aiwolf_tutorial.player;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.aiwolf.common.data.Agent;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

public class T_BodyguardPlayer extends T_BasePlayer {

	/** 護衛履歴(成功/失敗問わず) */
	private List<Agent> guardHistory = new ArrayList<Agent>();
	/** 護衛に成功した対象 */
	private Set<Agent> successfullGuardHistory = new LinkedHashSet<Agent>();
	/** 昨日の護衛対象 */
	private Agent latestGuardTarget;

	@Override
	public void initialize(GameInfo gameInfo, GameSetting gameSetting) {
		super.initialize(gameInfo, gameSetting);
		// 各変数・インスタンスの初期化
		guardHistory.clear();
		successfullGuardHistory.clear();
		latestGuardTarget = null;
	}

	@Override
	public void dayStart() {
		super.dayStart();
		// 昨夜の襲撃が失敗=護衛が成功 のため，記録
		if(currentGameInfo.getLastDeadAgentList().isEmpty() && latestGuardTarget != null) {
			successfullGuardHistory.add(latestGuardTarget);
		}
	}

	@Override
	public String talk() {
		// 生存している自分以外のエージェントから，ランダムに投票先を決め
		// 誰から何を言われようが，例え対象が占い師を名乗っていようが
		// その意思を変えない戦略
		// (村人と同じ行動パターン)
		if(voteCandidate == null) {
			voteCandidate = randomSelect(aliveOthers);
			talkQueue.addVoteContent(me, voteCandidate);
		}
		return super.talk();
	}

	@Override
	public Agent guard() {
		// 生存エージェントからランダムに選ぶ
		latestGuardTarget = randomSelect(aliveOthers);
		// 護衛履歴に記録
		guardHistory.add(latestGuardTarget);
		return latestGuardTarget;
	}

}
