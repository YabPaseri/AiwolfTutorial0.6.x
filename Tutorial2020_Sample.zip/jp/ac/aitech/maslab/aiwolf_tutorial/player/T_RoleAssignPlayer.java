package jp.ac.aitech.maslab.aiwolf_tutorial.player;

import org.aiwolf.sample.lib.AbstractRoleAssignPlayer;

public class T_RoleAssignPlayer extends AbstractRoleAssignPlayer {

	public T_RoleAssignPlayer() {
		setVillagerPlayer(new T_VillagerPlayer());
		setBodyguardPlayer(new T_BodyguardPlayer());
		setMediumPlayer(new T_MediumPlayer());
		setPossessedPlayer(new T_PossessedPlayer());
		setSeerPlayer(new T_SeerPlayer());
		setWerewolfPlayer(new T_WerewolfPlayer());
	}

	@Override
	public String getName() {
		return "Tutorial2020";
	}

}
