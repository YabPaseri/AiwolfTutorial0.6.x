/**
 * Talkの作成・管理をしやすくするためのクラス
 *
 * @author Hiroki Oyabu
 */

package jp.ac.aitech.maslab.aiwolf_tutorial.util;

import java.util.ArrayDeque;

import org.aiwolf.client.lib.AgreeContentBuilder;
import org.aiwolf.client.lib.AndContentBuilder;
import org.aiwolf.client.lib.AttackContentBuilder;
import org.aiwolf.client.lib.AttackedContentBuilder;
import org.aiwolf.client.lib.BecauseContentBuilder;
import org.aiwolf.client.lib.ComingoutContentBuilder;
import org.aiwolf.client.lib.Content;
import org.aiwolf.client.lib.DayContentBuilder;
import org.aiwolf.client.lib.DisagreeContentBuilder;
import org.aiwolf.client.lib.DivinationContentBuilder;
import org.aiwolf.client.lib.DivinedResultContentBuilder;
import org.aiwolf.client.lib.EstimateContentBuilder;
import org.aiwolf.client.lib.GuardCandidateContentBuilder;
import org.aiwolf.client.lib.GuardedAgentContentBuilder;
import org.aiwolf.client.lib.IdentContentBuilder;
import org.aiwolf.client.lib.InquiryContentBuilder;
import org.aiwolf.client.lib.NotContentBuilder;
import org.aiwolf.client.lib.OrContentBuilder;
import org.aiwolf.client.lib.RequestContentBuilder;
import org.aiwolf.client.lib.TalkType;
import org.aiwolf.client.lib.VoteContentBuilder;
import org.aiwolf.client.lib.VotedContentBuilder;
import org.aiwolf.client.lib.XorContentBuilder;
import org.aiwolf.common.data.Agent;
import org.aiwolf.common.data.Role;
import org.aiwolf.common.data.Species;
import org.aiwolf.common.data.Talk;

public class TalkQueue {

	private ArrayDeque<Content> queue = new ArrayDeque<Content>();
	private Agent me;
	private boolean ecis = false;
	private Content lastContent = null;

	public TalkQueue(Agent me) {
		this.me = me;
	}

	/**
	 * 連続する同一発言の除外
	 * (Exclusion of consecutive identical statements)
	 * をするかのフラグをセットする(しない=false)(default=false)
	 * <div>例：「Aが人狼だと思う」を2連続で言うことを除外する など</div>
	 *
	 * フラグが発動するタイミングは，TalkQueue.talk()内のみであり，
	 * returnする内容が前回の内容と一致しているかで判別をしている．
	 * 除外した結果発言する内容がない場合は，SKIPが返ってくる．
	 */
	public void isECIS(boolean enabled) {
		ecis = enabled;
	}

	/**
	 * Contentをキューに追加するメソッド．追加に成功すればTrue，失敗するとFalseを返す．
	 */
	public boolean addContent(Content content) {
		try {
			queue.addLast(content);
		} catch (NullPointerException e) {
			return false;
		}
		return true;
	}

	/**
	 * キューの先頭要素を取得，及び削除するメソッド．
	 * 要素がない場合はnullを返す
	 */
	public Content pollFirstContent() {
		return queue.pollFirst();
	}

	/**
	 * キューの最後の要素を取得，及び削除するメソッド．
	 * 要素がない場合はnullを返す
	 */
	public Content pollLastContent() {
		return queue.pollLast();
	}

	/**
	 * キューの先頭要素を取得するメソッド．削除はされない．
	 * 要素がない場合はnullを返す
	 */
	public Content peekFitstContent() {
		return queue.peekFirst();
	}

	/**
	 * キューの最後の要素を取得するメソッド．削除はされない．
	 * 要素がない場合は，nullを返す
	 */
	public Content peekLastContent() {
		return queue.peekLast();
	}

	/**
	 * キューの先頭要素を削除し，String型に変換して返すメソッド．
	 * 要素がない場合は，SKIPを返す
	 * Playerを実装したクラスのtalkメソッドから呼ぶのに適している．
	 */
	public String talk() {
		Content content = null;
		if(ecis) {
			while(!queue.isEmpty()) {
				content = queue.pollFirst();
				if(lastContent == null) {
					break;
				} else {
					if(lastContent.equals(content)) {
						content = null;
					} else {
						break;
					}
				}
			}
		} else {
			content = queue.pollFirst();
		}
		if(content == null) {
			lastContent = Content.SKIP;
			return Talk.SKIP;
		} else {
			lastContent = content;
		}
		if(content.getSubject() == me) {
			return Content.stripSubject(content.getText());
		}
		return content.getText();
	}

	/**
	 * キューの要素の数を返すメソッド
	 */
	public int size() {
		return queue.size();
	}

	/**
	 * キューのクリア，前回発言のクリアを行うメソッド
	 */
	public void clear() {
		queue.clear();
		lastContent = null;
	}

	/**
	 * キューの複製を返すメソッド
	 */
	public ArrayDeque<Content> getClone() {
		return queue.clone();
	}

	// 発話生成を簡略化するためのwrapper
	/**
	 * 同意([subject]も[talk]と同じ意見である)
	 * @param subject
	 * @param talkType
	 * @param talkDay
	 * @param talkID
	 */
	public static Content agreeContent(Agent subject, TalkType talkType, int talkDay, int talkID) {
		return new Content(new AgreeContentBuilder(subject, talkType, talkDay, talkID));
	}

	/**
	 * キューにagreeを追加する
	 * @param subject
	 * @param talkType
	 * @param talkDay
	 * @param talkID
	 */
	public void addAgreeContent(Agent subject, TalkType talkType, int talkDay, int talkID) {
		addContent(agreeContent(subject, talkType, talkDay, talkID));
	}

	/**
	 * 非同意([subject]は[talk]とは違う意見である)
	 * @param subject
	 * @param talkType
	 * @param talkDay
	 * @param talkID
	 */
	public static Content disagreeContent(Agent subject, TalkType talkType, int talkDay, int talkID) {
		return new Content(new DisagreeContentBuilder(subject, talkType, talkDay, talkID));
	}

	/**
	 * キューにdisagreeを追加する
	 * @param subject
	 * @param talkType
	 * @param talkDay
	 * @param talkID
	 */
	public void addDisagreeContent(Agent subject, TalkType talkType, int talkDay, int talkID) {
		addContent(disagreeContent(subject, talkType, talkDay, talkID));
	}

	/**
	 * 投票意思([target]に投票する)
	 * @param subject
	 * @param target
	 */
	public static Content voteContent(Agent subject, Agent target) {
		return new Content(new VoteContentBuilder(subject, target));
	}

	/**
	 * キューにvoteを追加する
	 * @param subject
	 * @param target
	 */
	public void addVoteContent(Agent subject, Agent target) {
		addContent(voteContent(subject, target));
	}

	/**
	 * 投票結果([target]に投票した)
	 * @param subject
	 * @param target
	 */
	public static Content votedContent(Agent subject, Agent target) {
		return new Content(new VotedContentBuilder(subject, target));
	}

	/**
	 * キューにvotedを追加する
	 * @param subject
	 * @param target
	 */
	public void addVotedContent(Agent subject, Agent target) {
		addContent(votedContent(subject, target));
	}

	/**
	 * 襲撃意思([target]を襲撃する)
	 * @param subject
	 * @param target
	 */
	public static Content attackContent(Agent subject, Agent target) {
		return new Content(new AttackContentBuilder(subject, target));
	}

	/**
	 * キューにattackを追加する
	 * @param subject
	 * @param target
	 */
	public void addAttackContent(Agent subject, Agent target) {
		addContent(attackContent(subject, target));
	}

	/**
	 * 襲撃結果([target]を襲撃した)
	 * @param subject
	 * @param target
	 */
	public static Content attackedContent(Agent subject, Agent target) {
		return new Content(new AttackedContentBuilder(subject, target));
	}

	/**
	 * キューにattackedを追加する
	 * @param subject
	 * @param target
	 */
	public void addAttackedContent(Agent subject, Agent target) {
		addContent(attackedContent(subject, target));
	}

	/**
	 * 護衛意思([target]を護衛する)
	 * @param subject
	 * @param target
	 */
	public static Content guardContent(Agent subject, Agent target) {
		return new Content(new GuardCandidateContentBuilder(subject, target));
	}

	/**
	 * キューにguardを追加する
	 * @param subject
	 * @param target
	 */
	public void addGuardContent(Agent subject, Agent target) {
		addContent(guardContent(subject, target));
	}

	/**
	 * 護衛結果([target]を護衛した)
	 * @param subject
	 * @param target
	 */
	public static Content guardedContent(Agent subject, Agent target) {
		return new Content(new GuardedAgentContentBuilder(subject, target));
	}

	/**
	 * キューにguardedを追加する
	 * @param subject
	 * @param target
	 */
	public void addGuardedContent(Agent subject, Agent target) {
		addContent(guardedContent(subject, target));
	}

	/**
	 * 推測([target]は[role]だと思う)
	 * @param subject
	 * @param target
	 * @param role
	 */
	public static Content estimateContent(Agent subject, Agent target, Role role) {
		return new Content(new EstimateContentBuilder(subject, target, role));
	}

	/**
	 * キューにestimateを追加する
	 * @param subject
	 * @param target
	 * @param role
	 */
	public void addEstimateContent(Agent subject, Agent target, Role role) {
		addContent(estimateContent(subject, target, role));
	}

	/**
	 * 宣言([target]は[role]である)
	 * @param subject
	 * @param target
	 * @param role
	 */
	public static Content coContent(Agent subject, Agent target, Role role) {
		return new Content(new ComingoutContentBuilder(subject, target, role));
	}

	/**
	 * キューにcoを追加する
	 * @param subject
	 * @param target
	 * @param role
	 */
	public void addCoContent(Agent subject, Agent target, Role role) {
		addContent(coContent(subject, target, role));
	}

	/**
	 * 行動要求・状態達成要求([content]をして欲しい,[content]になって欲しい)
	 * <div>requestとinquireの区別は公式ドキュメント参照</div>
	 * @see <a href=http://aiwolf.org/control-panel/wp-content/uploads/2019/02/protocol_2019_3_6m.pdf>http://aiwolf.org/control-panel/wp-content/uploads/2019/02/protocol_2019_3_6m.pdf</a>
	 * @param subject
	 * @param target
	 * @param content
	 */
	public static Content requestContent(Agent subject, Agent target, Content content) {
		return new Content(new RequestContentBuilder(subject, target, content));
	}

	/**
	 * キューにrequestを追加する
	 * @param subject
	 * @param target
	 * @param content
	 */
	public void addRequestContent(Agent subject, Agent target, Content content) {
		addContent(requestContent(subject, target, content));
	}

	/**
	 * 現在状態要求([content]だと思うか，[content]したか)
	 * <div>requestとinquireの区別は公式ドキュメント参照</div>
	 * @see <a href=http://aiwolf.org/control-panel/wp-content/uploads/2019/02/protocol_2019_3_6m.pdf>http://aiwolf.org/control-panel/wp-content/uploads/2019/02/protocol_2019_3_6m.pdf</a>
	 * @param subject
	 * @param target
	 * @param content
	 */
	public static Content inquiryContent(Agent subject, Agent target, Content content) {
		return new Content(new InquiryContentBuilder(subject, target, content));
	}

	/**
	 * キューにinquiryを追加する
	 * @param subject
	 * @param target
	 * @param content
	 */
	public void addInquiryContent(Agent subject, Agent target, Content content) {
		addContent(inquiryContent(subject, target, content));
	}

	/**
	 * 占い意思([target]を占う)
	 * @param subject
	 * @param target
	 */
	public static Content divinationContent(Agent subject, Agent target) {
		return new Content(new DivinationContentBuilder(subject, target));
	}

	/**
	 * キューにdivinationを追加する
	 * @param subject
	 * @param target
	 */
	public void addDivinationContent(Agent subject, Agent target) {
		addContent(divinationContent(subject, target));
	}

	/**
	 * 占い結果([target]を占った結果[species]だった)
	 * @param subject
	 * @param target
	 * @param result
	 */
	public static Content divinedContent(Agent subject, Agent target, Species result) {
		return new Content(new DivinedResultContentBuilder(subject, target, result));
	}

	/**
	 * キューにdivinedを追加する
	 * @param subject
	 * @param target
	 * @param result
	 */
	public void addDivinedContent(Agent subject, Agent target, Species result) {
		addContent(divinedContent(subject, target, result));
	}

	/**
	 * 霊媒結果([target]の霊媒結果は[species]だった)
	 * @param subject
	 * @param target
	 * @param result
	 */
	public static Content identContent(Agent subject, Agent target, Species result) {
		return new Content(new IdentContentBuilder(subject, target, result));
	}

	/**
	 * キューにidentを追加する
	 * @param subject
	 * @param target
	 * @param result
	 */
	public void addIdentContent(Agent subject, Agent target, Species result) {
		addContent(identContent(subject, target, result));
	}

	/**
	 * ~かつ([content]かつ[content]である) -> すべて真
	 * @param subject
	 * @param contents
	 */
	public static Content andContent(Agent subject, Content... contents) {
		return new Content(new AndContentBuilder(subject, contents));
	}

	/**
	 * キューにandを追加する
	 * @param subject
	 * @param contents
	 */
	public void addAndContent(Agent subject, Content... contents) {
		addContent(andContent(subject, contents));
	}

	/**
	 * ~または([content]または[content]である) -> 1つは真
	 * @param subject
	 * @param contents
	 */
	public static Content orContent(Agent subject, Content... contents) {
		return new Content(new OrContentBuilder(subject, contents));
	}

	/**
	 * キューにorを追加する
	 * @param subject
	 * @param contents
	 */
	public void addOrContent(Agent subject, Content... contents) {
		addContent(orContent(subject, contents));
	}

	/**
	 * ~のどちらか([content]か[content]のどちらかを主張する)
	 * @param subject
	 * @param content1
	 * @param content2
	 */
	public static Content xorContent(Agent subject, Content content1, Content content2) {
		return new Content(new XorContentBuilder(subject, content1, content2));
	}

	/**
	 * キューにxorを追加する
	 * @param subject
	 * @param content1
	 * @param content2
	 */
	public void addXorContent(Agent subject, Content content1, Content content2) {
		addContent(xorContent(subject, content1, content2));
	}

	/**
	 * 否定([content]ではない)
	 * @param subject
	 * @param content
	 */
	public static Content notContent(Agent subject, Content content) {
		return new Content(new NotContentBuilder(subject, content));
	}

	/**
	 * キューにnotを追加する
	 * @param subject
	 * @param content
	 */
	public void addNotContent(Agent subject, Content content) {
		addContent(notContent(subject, content));
	}

	/**
	 * 時間指定([day]のとき[content]である)
	 * @param subject
	 * @param day
	 * @param content
	 */
	public static Content dayContent(Agent subject, int day, Content content) {
		return new Content(new DayContentBuilder(subject, day, content));
	}

	/**
	 * キューにdayを追加する
	 * @param subject
	 * @param day
	 * @param content
	 */
	public void addDayContent(Agent subject, int day, Content content) {
		addContent(dayContent(subject, day, content));
	}

	/**
	 * 理由([reason]であるため[action]である/[action]をした)
	 * @param subject
	 * @param reason
	 * @param action
	 */
	public static Content becauseContent(Agent subject, Content reason, Content action) {
		return new Content(new BecauseContentBuilder(subject, reason, action));
	}

	/**
	 * キューにbecauseを追加する
	 * @param subject
	 * @param reason
	 * @param action
	 */
	public void addBecauseContent(Agent subject, Content reason, Content action) {
		addContent(becauseContent(subject, reason, action));
	}
}
