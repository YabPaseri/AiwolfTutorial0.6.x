package jp.ac.aitech.maslab.aiwolf_tutorial.player;

public class T_VillagerPlayer extends T_BasePlayer {

	@Override
	public String talk() {
		// 生存している自分以外のエージェントから，ランダムに投票先を決め
		// 誰から何を言われようが，例え対象が占い師を名乗っていようが
		// その意思を変えない戦略
		if(voteCandidate == null) {
			voteCandidate = randomSelect(aliveOthers);
			talkQueue.addVoteContent(me, voteCandidate);
		}
		return super.talk();
	}

}
