package jp.ac.aitech.maslab.aiwolf_tutorial.player;

import java.util.ArrayList;
import java.util.List;

import org.aiwolf.common.data.Agent;
import org.aiwolf.common.data.Role;
import org.aiwolf.common.data.Species;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

public class T_PossessedPlayer extends T_BasePlayer {

	// 偽占い師として振る舞う場合に使用する，各リスト．
	// 占い師の実装に準拠
	/** 占い結果が白エージェント */
	private List<Agent> whiteList = new ArrayList<Agent>();
	/** 占い結果が黒エージェント */
	private List<Agent> blackList = new ArrayList<Agent>();
	/** 占っていないエージェント */
	private List<Agent> grayList;

	/** 行動パターン-> 0:未確定，1:占い師騙り，2:村人と同じ行動 */
	private int behavioralPattern = 0;

	@Override
	public void initialize(GameInfo gameInfo, GameSetting gameSetting) {
		super.initialize(gameInfo, gameSetting);
		// 各変数・インスタンスの初期化
		whiteList.clear();
		blackList.clear();
		grayList = new ArrayList<Agent>(aliveOthers);
		behavioralPattern = 0;
	}

	@Override
	public String talk() {
		// 行動パターンが未決定で，占い師COを1人のエージェントがしている場合
		if(behavioralPattern == 0 && countCoRole(Role.SEER) == 1) {
			// 偽占い師として行動する
			behavioralPattern = 1;
			talkQueue.addCoContent(me, me, Role.SEER);
		}
		// 行動パターンが未決定で，占い師COを2人のエージェントがしている場合
		else if (behavioralPattern == 0 && 1 < countCoRole(Role.SEER)) {
			// 村人として行動する
			behavioralPattern = 2;
		}
		// 行動パターンが未決定もしくは村人の場合，村人エージェントの実装に準拠した動きをする
		if(behavioralPattern == 0 || behavioralPattern == 2) {
			// 生存している自分以外のエージェントから，ランダムに投票先を決め
			// 誰から何を言われようが，例え対象が占い師を名乗っていようが
			// その意思を変えない戦略
			if(voteCandidate == null) {
				voteCandidate = randomSelect(aliveOthers);
				talkQueue.addVoteContent(me, voteCandidate);
			}
		}
		// 行動パターンが偽占い師の場合，占い師っぽく動く
		else if (behavioralPattern == 1) {
			// whiteListとblackListのサイズの合計が，今日までに占っていなければならない人数になるようにfor文を回す
			for(int i=whiteList.size() + blackList.size(); i < day; i++) {
				// グレーからランダムに1人選ぶ
				Agent target = randomSelect(grayList);
				// グレーリストからは除外
				grayList.remove(target);
				// ブラックリストに誰もいなければ，今回ランダムに選んだターゲットを黒として扱う
				if(blackList.isEmpty()) {
					blackList.add(target);
					talkQueue.addDivinedContent(me, target, Species.WEREWOLF);
				}
				// ブラックリストに誰かがいるなら，今回ランダムに選んだターゲットは白として扱う
				else {
					whiteList.add(target);
					talkQueue.addDivinedContent(me, target, Species.HUMAN);
				}
			}
		}
		return super.talk();
	}

	@Override
	public Agent vote() {
		// 行動パターンが未確定・村人の場合
		if(behavioralPattern == 0 || behavioralPattern == 2) {
			// 生存者の中からランダムに選んで返す(村人と違って，投票宣言した対象に投票するわけではない)
			return randomSelect(aliveOthers);
		}
		// 行動パターンが偽占い師の場合
		else if (behavioralPattern == 1){
			// (ならないはずだけども）blackListが空なら，グレーから適当に返す
			if(blackList.isEmpty()) {
				return randomSelect(grayList);
			}
			// blackListが空ではないとき
			else {
				// blackListのエージェントに生存者がいるかを確認
				Agent target = null;
				for(Agent tmp : blackList) {
					if (isAlive(tmp)) {
						target = tmp;
						break;
					}
				}
				// 三項演算子の組み合わせなので読みづらいがファイト
				// reutrn (blackListの生存者がいない) ? { いないとき -> (グレーリストが空) ? 空のとき : 空ではないとき } : いるとき;
				// blackListの生存者がいる->blackListの生存者を返す
				// blackListの生存者がいない->グレーリストが空のとき->自分以外の生存者リストからランダムに選んで返す
				// blackListの生存者がいない->グレーリストが空ではないとき->グレーリストからランダムに選んで返す
				return (target == null) ? (grayList.isEmpty() ? randomSelect(aliveOthers) : randomSelect(grayList)) : target;
			}
		}
		// 仕様上，作る必要があったreturn
		else {
			return randomSelect(aliveOthers);
		}
	}
}
