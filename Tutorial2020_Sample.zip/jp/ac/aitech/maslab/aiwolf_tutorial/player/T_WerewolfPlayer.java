package jp.ac.aitech.maslab.aiwolf_tutorial.player;

import org.aiwolf.common.data.Agent;

public class T_WerewolfPlayer extends T_BasePlayer {

	@Override
	public String talk() {
		// 生存している自分以外のエージェントから，ランダムに投票先を決め
		// 誰から何を言われようが，例え対象が占い師を名乗っていようが
		// その意思を変えない戦略
		// (村人と同じ行動パターン)
		if(voteCandidate == null) {
			voteCandidate = randomSelect(aliveOthers);
			talkQueue.addVoteContent(me, voteCandidate);
		}
		return super.talk();
	}

	@Override
	public Agent attack() {
		// 生存者からランダムに襲撃する
		return randomSelect(aliveOthers);
	}
}
