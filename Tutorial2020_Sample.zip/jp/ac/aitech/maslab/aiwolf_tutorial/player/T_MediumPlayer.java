package jp.ac.aitech.maslab.aiwolf_tutorial.player;

import java.util.ArrayList;
import java.util.List;

import org.aiwolf.common.data.Judge;
import org.aiwolf.common.data.Role;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

public class T_MediumPlayer extends T_BasePlayer {

	/** 霊媒結果を保存するリスト */
	private List<Judge> identResultList = new ArrayList<Judge>();

	/** 霊媒結果のリストの何番目まで，公表したか */
	private int identResultListHead;

	/** CO済みかどうか */
	private boolean alreadyCO;

	@Override
	public void initialize(GameInfo gameInfo, GameSetting gameSetting) {
		super.initialize(gameInfo, gameSetting);
		// 各変数・インスタンスの初期化
		identResultList.clear();
		identResultListHead = 0;
		alreadyCO = false;
	}

	@Override
	public void dayStart() {
		super.dayStart();
		// 霊媒結果が存在している場合は，リストに追加する
		if(currentGameInfo.getMediumResult() != null) {
			identResultList.add(currentGameInfo.getMediumResult());
		}
	}

	@Override
	public String talk() {
		// 初日は村人と同じ動き
		if(day == 1) {
			// 生存している自分以外のエージェントから，ランダムに投票先を決め
			// 誰から何を言われようが，例え対象が占い師を名乗っていようが
			// その意思を変えない戦略
			if(voteCandidate == null) {
				voteCandidate = randomSelect(aliveOthers);
				talkQueue.addVoteContent(me, voteCandidate);
			}
		}
		// 2日目以降は，結果を淡々と言う
		else {
			// COをまだしていなければ，COをする
			if(!alreadyCO) {
				talkQueue.addCoContent(me, me, Role.MEDIUM);
				alreadyCO = true;
			}
			// 霊媒結果を報告する
			for(int i=identResultListHead; i<identResultList.size(); i++) {
				talkQueue.addIdentContent(me, identResultList.get(i).getTarget(), identResultList.get(i).getResult());
			}
			identResultListHead = identResultList.size();
		}
		return super.talk();
	}
}
