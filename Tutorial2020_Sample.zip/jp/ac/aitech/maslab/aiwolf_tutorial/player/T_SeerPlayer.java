package jp.ac.aitech.maslab.aiwolf_tutorial.player;

import org.aiwolf.common.data.Agent;
import org.aiwolf.common.data.Judge;
import org.aiwolf.common.data.Species;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

public class T_SeerPlayer extends T_BasePlayer {

	/** 占い結果が人間のエージェントのリスト */
	// Tips: AgentのArrayList

	/** 占い結果が人狼のエージェントのリスト */
	// Tips: AgentのArrayList

	/** まだ占っていないエージェントのリスト */
	// Tips: AgentのArrayList


	/** 最新の占い結果 */
	private Judge latestDivineResult;
	/** カミングアウト済みかどうか */
	private boolean alreadyCO;


	@Override
	public void initialize(GameInfo gameInfo, GameSetting gameSetting) {
		super.initialize(gameInfo, gameSetting);
		/** Start: 作成したリストを初期化 */



		/** End  : 作成したリストを初期化 */

		// 他の変数も初期化
		latestDivineResult = null;
		alreadyCO = false;
	}

	@Override
	public void update(GameInfo gameInfo) {
		super.update(gameInfo);
	}

	@Override
	public void dayStart() {
		super.dayStart();
		// 占い結果を取得
		latestDivineResult = currentGameInfo.getDivineResult();
		// 占い結果がnullでなければ，処理を開始
		if(latestDivineResult != null) {
			/** Start: まだ占っていないエージェントのリストから，占い結果の対象を削除 */

			/** End  : まだ占っていないエージェントのリストから，占い結果の対象を削除 */

			// 占った結果が人間だった場合は
			if(latestDivineResult.getResult() == Species.HUMAN) {
				/** Start: 占い結果が人間のエージェントリストに，今回占ったエージェントを追加 */

				/** End  : 占い結果が人間のエージェントリストに，今回占ったエージェントを追加 */
			}
			// 占った結果が人狼だった場合は
			else {
				/** Start: 占い結果が人狼のエージェントリストに，今回占ったエージェントを追加 */

				/** End  : 占い結果が人狼のエージェントリストに，今回占ったエージェントを追加 */
			}
		}
	}

	@Override
	public String talk() {
		// カミングアウトしていないなら
		if(!alreadyCO) {
			/** Start: talkQueueに「自分は占い師である」というカミングアウトの会話を追加 */

			/** End  : talkQueueに「自分は占い師である」というカミングアウトの会話を追加 */
			alreadyCO = true;
		}
		// 今回の占い結果を発言していない場合
		if(latestDivineResult != null) {
			/** Start: talkQueueに占い結果を追加 */

			/** End  : talkQueueに占い結果を追加 */
			latestDivineResult = null;
		}
		return super.talk();
	}

	@Override
	public Agent vote() {
		/** Start: 占い結果が人狼のリストが空の場合は，randomSelectメソッドを使って
		 *         まだ占っていないエージェントのリストから誰かに投票する */



		/** End  : 占い結果が人狼のリストが空の場合は，randomSelectメソッドを使って
		 *         まだ占っていないエージェントのリストから誰かに投票する */

		/** Start: 占い結果が人狼のリストが空ではない場合は，
		 *         そのリストの中に生存者がいる場合は，その生存しているエージェントに投票する．
		 *         占い結果が人狼のリストに生存者がいない場合は，まだ占っていないエージェントリストから誰かに投票する */






		/** End  : 占い結果が人狼のリストが空ではない場合は，
		 *         そのリストの中に生存者がいる場合は，その生存しているエージェントに投票する．
		 *         占い結果が人狼のリストに生存者がいない場合は，まだ占っていないエージェントリストから誰かに投票する */
	}


	@Override
	public Agent divine() {
		/** Start: まだ占っていないエージェントリストから，ランダムに占う(ランダムにreturnする) */


		/** End  : まだ占っていないエージェントリストから，ランダムに占う(ランダムにreturnする) */
	}

	@Override
	public void finish() {
		super.finish();
	}

}
